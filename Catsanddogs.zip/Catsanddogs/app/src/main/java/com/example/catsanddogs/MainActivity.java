package com.example.catsanddogs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Cat[] cats=new Cat[5];
        for(int i=0;i<5;i++){
            cats[i]=new Cat("Cat"+i,new Random().nextInt(5));
            System.out.println(cats[i].name+"-"+cats[i].age);
        }
        Dog[] dogs=new Dog[5];
        for(int i=0;i<5;i++){
            dogs[i]=new Dog("Dog"+i,new Random().nextInt(5));
            System.out.println(dogs[i].name+"-"+dogs[i].age);
        }
        System.out.println("============");

        for (int i=0; i<5;i++){//cats
            cats[i].meow();
            for (int j=0; j<5;j++){//dogs
                if(dogs[j].age>cats[i].age){
                    dogs[j].bark();
                }
            }
        }


    }
    class Dog {
        String name="";
        int age=0;

        public Dog(String name, int age) {
            this.name = name;
            this.age = age;
        }
        public void bark(){
            System.out.println(name+": Woof");
        }
    }
    class Cat {
        String name="";
        int age=0;

        public Cat(String name, int age) {
            this.name = name;
            this.age = age;
        }
        public void meow(){
            System.out.println(name+": Meow");
        }
    }

}